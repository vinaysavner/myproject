// Create your event by using "events" module
const EventEmitter = require("events");

// crate an object of EventEmitter
const event = new EventEmitter();

//create or listen custom event
event.on("myEvent", () => {
    console.log("Called myEvent");
})

event.on("checkPage", (sc, msg) => {
    console.log(`Called checkPage event, It's status code is : ${sc} and message is : ${msg}`);
})

//emit is used to assign or fire event
event.emit("myEvent");
event.emit("checkPage", 200, "ok");
