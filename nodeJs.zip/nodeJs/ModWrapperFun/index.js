//This is modWrapper 
// (function(exports, require, module, __filename, __dirname){
// });
console.log(__filename);
console.log(__dirname);