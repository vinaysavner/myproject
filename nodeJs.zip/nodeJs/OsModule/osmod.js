const os = require("os");

console.log('Bit : '+ os.arch());
console.log('Host name : '+ os.hostname());
console.log('Platform name : '+ os.platform());
console.log('Temprory directory name : '+ os.tmpdir());
console.log('Type : '+ os.type());
console.log('Free memory : '+ `${ os.freemem() / 1024 / 1024 / 1024 }`);
console.log('Total memory : '+ `${os.totalmem() / 1024 / 1024 / 1024 }`);