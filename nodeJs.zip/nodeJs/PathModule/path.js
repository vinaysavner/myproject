const path = require('path');

console.log('Path : '+ path.dirname('D:/nodeJs/PathModule/path.js'));
console.log('Extention : '+ path.extname('D:/nodeJs/PathModule/path.js'));
console.log('File name : '+ path.basename('D:/nodeJs/PathModule/path.js'));

const dataObj = path.parse('D:/nodeJs/PathModule/path.js');
console.log('File path by data object : '+ dataObj.name);
console.log('File root by data object : '+ dataObj.root);