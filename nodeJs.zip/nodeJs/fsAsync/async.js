const fs = require('fs'); 

// fs.mkdir("thapa", (err)=> {
//     console.log("success");
// });

// fs.writeFile("thapa/bio.txt", "this is async bio.txt", (err)=>{
//     console.log("success");
// })

// fs.appendFile("thapa/bio.txt", " : append operation", (err)=>{
//     console.log("success");
// })

// fs.readFile("thapa/bio.txt", "utf8", (err,data)=>{
//     console.log("success");
//     console.log(data);
// })

// fs.rename("thapa/bio.txt", "thapa/mybio.txt", (err,data)=>{
//     console.log("success");
// })

// fs.unlink("thapa/mybio.txt",(err,data)=>{
//     console.log("success");
// })

// fs.rmdir("./thapa",(err,data)=>{
//     console.log("success");
// })