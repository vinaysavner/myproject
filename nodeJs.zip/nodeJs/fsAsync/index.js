const fs =  require("fs");

// callback function required in Async
// fs.writeFile("read.txt", "hello vinay savner", (err) => {
//     console.log("Success");
//     console.log(err);
// });

//append data 
// fs.appendFile("read.txt", " : Nice to see you again.", (err) => {
//     console.log("Success");
// });

// fs.readFile("read.txt", "utf8",(err,data) => {
//     console.log("Success");
//     console.log(data);
// });

// fs.writeFile("async.js", "This is Asunc file system", (err) => {
//     console.log("success");
// });
