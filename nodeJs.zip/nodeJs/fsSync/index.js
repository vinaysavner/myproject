const fs = require("fs");

// Write file it will first create file then write in file or overwrite in file 
fs.writeFileSync("read.txt", "Welcome Vinay Savner");

// appent data in file
fs.appendFileSync ("read.txt", " Nice to see you");

// Read data from file 
// return type will be BUFFER , bydefault readfile return buffer type, 
// which is note available in js it additional datatype.
// used to get bynary data
const buf_data =  fs.readFileSync("read.txt");
const str_data = buf_data.toString();
console.log(str_data);

// encoded 
const str_data =  fs.readFileSync("read.txt", "utf8");
console.log(str_data)
// rename the file
fs.renameSync('read.txt', 'readwrite.txt');

//remove file
// fs.unlinkSync()

//remove folder
// fs.rmdirSync()