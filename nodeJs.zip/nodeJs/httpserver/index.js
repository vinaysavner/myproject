const http = require("http");
const fs = require("fs");
// use below code for url's
// const url = require("url"); or req.url in below server function

const server = http.createServer((req, res) => {
    if(req.url== "/"){
        res.end("This is Home page");
    }else if(req.url == "/aboutUs"){
        res.end("This is About Us page");
    }else if(req.url == "/contactUs"){
        res.end("This is Contact Us page");
    }else if(req.url == "/userapi"){
        fs.readFile(`${__dirname}/UserApi/userapi.json`,"utf8",(err, data) => {
            res.end(data);
        })
        
    }else{
        res.writeHead(404, {"Content-type" : "text/html"});
        res.end("<h1>404 : Page not found</h1>");
    }
});

server.listen(8000, "127.0.0.1", () => {
    console.log("Listening to the port no 8000");
});