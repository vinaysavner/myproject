const { name, add, sub, mult } = require('./oper');
console.log('Add : '+add(5, 5));
console.log('Sub : '+sub(10, 5));
console.log('Mult : '+mult(10, 5));
console.log('Name : '+name);