const fs = require("fs");
// JSON Object
const bioData = {
    name : "Vinay Savner",
    age : 24,
    description : "Nodejs practice"
}
// console.log(bioData); // { name: 'Vinay Savner', age: 24 }

// Convert  Object to JSON
const jsonData = JSON.stringify(bioData);
console.log(jsonData); 

//add json to an other file
fs.writeFile("json1.json",jsonData,(err)=>{
    console.log("done");
});

//read newly created json file
fs.readFile("json1.json", "utf8", (err, data) => {
    // Convert JSON to Object
    const objectData = JSON.parse(data);
    console.log(objectData); // { name: 'Vinay Savner', age: 24 }
})





