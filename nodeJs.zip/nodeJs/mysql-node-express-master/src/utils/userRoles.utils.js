module.exports = {
    Admin: 'Admin',
    SuperUser: 'SuperUser'
}