const express = require("express"); 
const hbs = require("hbs");
const path = require("path");
require("./db/conn");
const User = require("./models/contactus");

const app = express();
const port = process.env.PORT || 8000;
// hbs.registerPartials

//setting the path
const staticPath = path.join(__dirname, "../public");
const templatePath = path.join(__dirname, "../templates/views");
const partialPath = path.join(__dirname, "../templates/partials");
// console.log(staticPath);

//middleware
app.use("/css", express.static(path.join(__dirname, "../node_modules/bootstrap/dist/css")));
app.use("/js", express.static(path.join(__dirname, "../node_modules/bootstrap/dist/js")));
app.use("/jq", express.static(path.join(__dirname, "../node_modules/jquery/dist")));

app.use(express.urlencoded({extended:false}));
app.use(express.static(staticPath));
app.set("view engine", "hbs");
app.set("views", templatePath);
hbs.registerPartials(partialPath);


//routing
app.get("/",(req, res) => {
    res.render("index");
})
app.get("/services",(req, res) => {
    res.render("index");
})
app.get("/portfolio",(req, res) => {
    res.render("index");
})
app.get("/about",(req, res) => {
    res.render("index");
})
app.get("/team",(req, res) => {
    res.render("index");
})
app.get("/contact",(req, res) => {
    res.render("index");
})
app.post("/contact", async (req, res) => {
    try {
        const userData = new User(req.body);
        await userData.save();
        res.status(201).render("index");
    } catch (error) {
        res.status(500).send(error);        
    }
})
//listen to port
app.listen(port, () => {
    console.log(`listening to ${port}`);
});