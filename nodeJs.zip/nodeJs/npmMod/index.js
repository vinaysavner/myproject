const chalk = require('chalk');
const validatore = require('validator');

console.log(chalk.blue.inverse("Hello vinay"));

const res = validatore.isEmail("vinay.savner@hiteshi.com");
console.log(res ? chalk.green.inverse(res) : chalk.red.inverse(res));